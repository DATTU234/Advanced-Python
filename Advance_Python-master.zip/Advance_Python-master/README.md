# Advance_Python

Some advance concepts of Python. Series taken by [@Devyanshu](https://github.com/Devyanshu).

#### See submissions.md in Solutions for how to upload your code.

### Leaderboard

|   Name   | Score |
|:--------:|:-----:|
| Arjun009 |   12  |
| Aryan Lala |   8 |
|  SaiSudhamsa|   8   |
| Kartikay |   7   |
| Aryan    |   4   |
|  Prachi  |   3   |

#### Leaderboard will be updated every week. Make sure that you make a pull request before the next class.
